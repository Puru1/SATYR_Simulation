function [tau_lin] = fnc_tauLin()

tau_lin = zeros(2,1);

  tau_lin(1,1)=0;
  tau_lin(2,1)=0;

 