function [K] = fnc_K_orig()

K = zeros(1,4);

  K(1,1)=-180;
  K(1,2)=-640;
  K(1,3)=-166;
  K(1,4)=-85;
