function [PosW] = fnc_PosW(q,L)

PosW = zeros(3,1);

  PosW(1,1)=q(1);
  PosW(2,1)=0;
  PosW(3,1)=0;

 